//https://balavishnuvj.com/blog/testing-lists-items-with-react-testing-library/

import { render, screen, fireEvent, within } from '@testing-library/react';
import Listings from './index';

test('Test Listings View', () => {

    const listArr = [
        {
            package: {name: 'react', version: '1.0'}
        }, 
        {
            package: {name: 'react-native', version: '1.0'}
        },
        {
            package: {name: 'react-test', version: '1.0'}
        },
    ];

    render(<Listings list={listArr} />);

    //const $ = require('jquery');

    const list = screen.getByRole("list", {});
    const { getAllByRole } = within(list)
    const items = getAllByRole("listitem")
    expect(items.length).toBe(3)

});
