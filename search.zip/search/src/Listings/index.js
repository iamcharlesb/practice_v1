const Listings = ({list}) => {

    return (<ul>
      {
        list && list.map((item, index) => {
          const { name, version } = item.package;
          return (<li className="listing" key={index}>Name: {name} <br/>Version: {version}</li>);
        })
      }
    </ul>)
  
  }
  
export default Listings;