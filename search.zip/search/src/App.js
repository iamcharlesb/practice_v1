import { useState } from 'react';
import logo from './logo.svg';
import './App.css';
import Listings from './Listings';

async function findNPMModule(query) {

  if( !query )
    return null;

  const response = await fetch(`https://registry.npmjs.org/-/v1/search?text=${query}&size=5`);
  const jsonResponse = await response.json();
  return jsonResponse;

}

const NPMView = () => {

  const [ list , setList ] = useState([]);

  const apiFindNPM = ( query ) => {

    findNPMModule(query).then(data => {
      
      if( !data )
        return;

      console.log('Data Objects - ', data.objects);
      setList(data.objects)

    }).catch(err => console.log('Error - ', err));

  }

  return (
    <div className="npm-wrapper">
      Search <input type="text" onChange={(e) => apiFindNPM(e.target.value)}/>
      <Listings list={list} />
    </div>
  );

}

function App() {
  return (
    <div className="App">
      <div>
        <NPMView />
      </div>
    </div>
  );
}

export default App;
