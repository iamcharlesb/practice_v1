//https://stackoverflow.com/questions/62473970/best-way-to-test-input-value-in-dom-testing-library-or-react-testing-library

import { render, screen, fireEvent, within } from '@testing-library/react';
import App from './App';
import Listings from './Listings';

const setup = () => {
  const utils = render(<CostInput />)
  const input = utils.getByLabelText('cost-input')
  return {
    input,
    ...utils,
  }
}

test('Test NPM View', () => {
  render(<App />);

  const linkElement = screen.getByText(/Search/i);
  //const $ = require('jquery');

  expect(linkElement).toBeInTheDocument();
  expect(screen.getByRole('textbox', {})).toHaveValue('');

  const input = screen.getByRole('textbox');
  fireEvent.change(input, {target: {value: 'javascript'}});
  expect(screen.getByRole('textbox', {})).toHaveValue('javascript');
  expect(screen.getByRole('list', {})).toBeInTheDocument();

  /*jest.setTimeout(30000);

  const list = screen.getByRole("list", {});
  const { getAllByRole } = within(list)
  const items = getAllByRole("listitem")
  expect(items.length).toBe(5)*/

});