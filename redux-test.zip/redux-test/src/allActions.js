import counterActions from './actions/counterActions'
import userActions from './actions/userActions'

const allActions = {
    counterActions,
    userActions
}

export default allActions