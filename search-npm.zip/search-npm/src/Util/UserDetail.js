import React from 'react';

const UserDetailsCtxt = React.createContext();

export default UserDetailsCtxt;