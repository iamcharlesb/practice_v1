const User = (state = {}, action) => {

    switch( action.type ) {
        case 'SIGNIN':
            return {
                ...state,
                loggedIn: true
            };
        case 'SIGNOUT':
            return {
							...state,
							loggedIn: false
            };
    }

}

export default User;
