import logo from './logo.svg';
import './App.css';
import UserDetailsCtxt from './Util/UserDetail';
import UserIdentity from './components/UserIdentity';
import NPMView from './components/NPMView';
import TodoView from './components/TodoView';
import Promises from './components/Promises';
import ContextView from './components/ContextView';
import Timer from './components/Timer';

//Super code on data manipulation
//https://stackblitz.com/edit/react-6vriup?file=src%2FApp.js

function App() {
  return (
    <UserDetailsCtxt.Provider value={{name: 'Charles', age: 36}}>
      <div className="App">  
        <UserIdentity />
        <div>
          <NPMView />
        </div>
        <br/><br/>
        <div>
          <TodoView />
        </div>
        <div>
          <Promises />
        </div>
        <div>
          <ContextView />
        </div>
        <div>
          <Timer />
        </div>
      </div>
    </UserDetailsCtxt.Provider>
  );
}

export default App;
