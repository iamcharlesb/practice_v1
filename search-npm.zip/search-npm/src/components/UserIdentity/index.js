import { useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import UserDetailsCtxt from '../../Util/UserDetail';

const UserIdentity = () => {

	const select = useSelector( state => state);
	const dispatch = useDispatch();
	const userInfo = useContext( UserDetailsCtxt );

	console.log('select - ', select, ' && userInfo - ', userInfo);

	return (
		<div>
				<button onClick={() => dispatch({type: "SIGNIN"})}>Sign In</button>
				<button onClick={() => dispatch({type: "SIGNOUT"})}>Sign Out</button>
				
				<p>User Status: {select && select.loggedIn ? 'Signed In' : 'Signed Out'}</p>

				<p>User Name: {userInfo.name}</p>

		</div>
	);

}

export default UserIdentity;
