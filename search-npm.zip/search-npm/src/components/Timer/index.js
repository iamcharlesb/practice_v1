import {useState, useEffect} from 'react';

//let timerLnk = null;

function Checkbox(val = false) {
    return (
        <input type="checkbox" name="" value="" checked={val} />
    )
}

const Timer = () => {

    const [time, setTime] = useState();
    const [checked, setChecked] = useState(false)
    const [timerLnk, setTimerLnk] = useState(null)

    function timer() {
        const timerObj = setInterval(() => {
            setTime(new Date().toString());
        }, 100);
        setTimerLnk( timerObj );
    }

    function startTimer() {
        timer();
        //setChecked( true );
    }

    function clearTimer() {
        //setChecked( false );
        clearInterval( timerLnk );
        setTimerLnk(null);
    }

    useEffect(() => {
        //timer();
    });

    return (
        <div>
            <br/><br/><br/>
            <div>Timer {time}</div>
            <div>
                <button onClick={() => startTimer()}>Start</button>
                <button onClick={() => clearTimer()}>Stop</button>
                {timerLnk}
                <input type="checkbox" name="" value="" checked={timerLnk !== null } onChange={(e) => e.target.checked === true ? startTimer() : clearTimer()} />
            </div>
        </div>
    )

}

export default Timer;