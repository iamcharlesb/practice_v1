import {useState, useHook} from 'react';
import { useEffect } from 'react';

const fetchQry = async ( qry ) => {

	if( !qry )
		return;

	const response = await fetch(`https://registry.npmjs.org/-/v1/search?text=${qry}&size=5`);
	const jsonResponse = await response.json();
	return jsonResponse;

}

const List = ( {items} ) => {
	return (
		<ul>
		{
			items && items.map((item, index) => {
			return (<li>Package Name: {item.package.name} <br/> Version: {item.package.version} <br/><br/></li>);
			})
		}
		</ul>
	)
}

const NPMView = () => {

	const [qry, srchQry] = useState('');
	const [data, setData] = useState([]);

	useEffect(() => {
		
		fetchQry(qry).then(response => response && setData( response.objects ) );

	}, [qry])

	return (
		<div>
				<input type="text" onChange={(e) => srchQry(e.target.value)} />
				<List items={data} />
		</div>
	); 
}

export default NPMView;