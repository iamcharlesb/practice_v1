import { useState } from 'react';
import './style.css';

const TodoView = () => {

	const [items, setItems] = useState([]);

	const [rdoItem, setRdoItem] = useState('');

	return (
		<div>

			<input type="text" onKeyUp={(e) => e.code === 'Enter' ? setItems([...items, e.target.value]) : null } />
			<ul>
					{items && items.map((item, index) => {

						return (
							<li key={index}>
								<input type="radio" value={item} checked={item === rdoItem} onChange={(e) => setRdoItem(e.target.value)}  />
								<span>{item}</span> <button onClick={() => {
								const arr = items.filter((item, id) => index !== id);
								setItems(arr);
							}}>X</button></li>
						);

					})}
					
			</ul>
		</div>
	)
}

export default TodoView;