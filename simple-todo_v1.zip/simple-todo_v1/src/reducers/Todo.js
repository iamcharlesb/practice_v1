const Todo = ( state = {todo: []}, action ) => {

    console.log('state = ', state)

    switch( action.type ) {
        case 'ADD_TODO':            
        return {
            todo: [...state.todo, action.payload]
        };
    }

}

export default Todo;