import {combineReducers} from 'redux';
import Todo  from './Todo';

const rootReducer = combineReducers({
    Todo
})

export default rootReducer;