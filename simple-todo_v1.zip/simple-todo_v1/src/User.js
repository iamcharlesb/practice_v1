import React, { useState, useEffect } from "react";

export default function User(props) {
  const [user, setUser] = useState(null);

  async function fetchUserData(id) {
    //const response = await fetch(`https://run.mocky.io/v3/b2a4fa53-871d-4aeb-95db-aa88b46845e8?${id}`);
    const response = await fetch(`https://run.mocky.io/v3/909ebd10-d151-4714-a0d2-edd63f6489c6?${id}`);
    setUser(await response.json());
  }

  useEffect(() => {
    fetchUserData(props.id);
  }, [props.id]);

  if (!user) {
    return "loading...";
  }

  return (
    <details>
      <summary>{user.name}</summary>
      <strong>{user.age}</strong> years old
      <br />
      lives in {user.address}
    </details>
  );
}