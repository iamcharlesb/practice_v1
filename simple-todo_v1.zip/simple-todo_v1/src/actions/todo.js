const addTodo = ( todoTitle ) => {

    console.log('todoTitle - ', todoTitle)

    return {
        type: "ADD_TODO",
        payload: todoTitle
    }
}

export default {
    addTodo
};