import todo from './todo';

const allActions = {
    todo
}

export default allActions;