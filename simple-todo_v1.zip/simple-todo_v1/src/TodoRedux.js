import {useSelector, useDispatch} from 'react-redux';
import actions from './actions';

console.log('allActions - ', actions)

const TodoRedux = () => {

    const list = [];

		const todoState = useSelector(state => state);
        const dispatch = useDispatch();

		//dispatch(actions.todo.addTodo(e.target.value)) 

		console.log('todoState - '. todoState);
		
		return (
        <div>
            <h1>Todo View</h1>

            <input type="text" name="" onKeyUp={(e) => e.code === 'Enter' ? dispatch( actions.todo.addTodo(e.target.value))  : null } /> 

            <ul>
								{todoState && todoState.todo.map((item, index) => {
                    return <li>{item}</li>
                })}
            </ul>
        </div>
    );

}

export default TodoRedux;